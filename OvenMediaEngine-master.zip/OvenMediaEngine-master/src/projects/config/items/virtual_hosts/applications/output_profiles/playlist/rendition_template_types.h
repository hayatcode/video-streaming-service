#pragma once

enum class EncodingType
{
	All,
	Encoded,
	Bypassed
};